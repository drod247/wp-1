<?php
    global $tust;
    $copyright_text = $tust['copyright-text'];

?>
         <footer class="footer-section">
		   <div class="container">
            <div class="row">
              
               <div class="col-md-12 uipasta-credit column-one">
                <p><?php echo $copyright_text; ?></p>
               </div>
               
            </div>
		   </div>
          </footer>
          <!-- Footer End -->
    
    
    
    
    <!-- Back to Top Start -->
    <a href="#" class="scroll-to-top"><i class="fa fa-long-arrow-up"></i></a>
    <!-- Back to Top End -->
    
    
    

  <?php
    wp_footer();
  ?>
  
  </body>
 </html>