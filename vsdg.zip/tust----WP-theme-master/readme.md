# This is a One page Wordpress Theme

[<img src="https://0.s3.envato.com/files/192487461/demo_button.png" width="400" height="350">](https://mortuzahossain.github.io/tust----WP-theme/)
[<img src="http://www.freeiconspng.com/uploads/downloading-png-22.png" width="400" height="350">](https://github.com/mortuzahossain/tust----WP-theme/archive/master.zip)
